# IMHO
### Menu
[ER-diagram](https://github.com/Distribuerede-Systemer-2017/IMHO-2/blob/master/documents/ER-diagram.png)
| [Flowchart](https://github.com/Distribuerede-Systemer-2017/IMHO-2/blob/master/documents/Flowchart_examQuiz.png)
 | [Usecase](https://github.com/Distribuerede-Systemer-2017/IMHO-2/blob/master/documents/Use%20cases.md) | [SQL](https://github.com/Distribuerede-Systemer-2017/IMHO-2/blob/master/src/main/java/server/resetdatabase/quizDB.sql) | [Contributing](https://github.com/Distribuerede-Systemer-2017/IMHO-2/blob/master/documents/contributing)|
